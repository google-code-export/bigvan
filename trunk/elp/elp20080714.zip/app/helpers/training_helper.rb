module TrainingHelper
end
