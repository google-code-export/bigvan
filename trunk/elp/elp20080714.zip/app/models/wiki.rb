class Wiki < ActiveRecord::Base
end
